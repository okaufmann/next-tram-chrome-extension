var nextTramApp = angular.module('NextTram', [
	'NextTramOpenDataService', 
	'NextTramOptionsService',
	'NextTramTimeTableService',
	'NextTramDirectives'
]);