var nextTramBackgroundApp = angular.module('NextTramBackground', [
	'NextTramOpenDataService',
	'NextTramOptionsService',
	'NextTramTimeTableService',
	'angularUUID2'
]);