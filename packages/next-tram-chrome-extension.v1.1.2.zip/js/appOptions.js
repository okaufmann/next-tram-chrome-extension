var nextTramOptionsApp = angular.module('NextTramOptions', [
	'NextTramOpenDataService',
	'ui.bootstrap'
]);