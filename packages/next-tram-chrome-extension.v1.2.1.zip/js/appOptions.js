var nextTramOptionsApp = angular.module('NextTramOptions', [
	'NextTramOpenDataService',
	'NextTramOptionsService',
	'ui.bootstrap',
	'angularUUID2'
]);