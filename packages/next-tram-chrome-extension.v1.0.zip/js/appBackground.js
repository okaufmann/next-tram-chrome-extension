var nextTramBackgroundApp = angular.module('NextTramBackground', [
	'NextTramOpenDataService'
]);