// Run our kitten generation script as soon as the document's DOM is ready.
/*document.addEventListener('DOMContentLoaded', function () {
	console.log("load");
	opendataReader.getdata(opendataReader.setdata);
});*/

nextTramApp.controller("PageController", function ($scope, OpenDataService) {
    
    $scope.message = "Your next Connections";
    $scope.connectionFrom = "";
    $scope.connectionTo = "";
	var settingConnections = localStorage["connection"];
	      var settingConnectionsObj = {};
	      if(settingConnections != null){
	        settingConnectionsObj = angular.fromJson(settingConnections);
	        $scope.connectionFrom = settingConnectionsObj.connection_from;
	        $scope.connectionTo = settingConnectionsObj.connection_to;
	      }else{

	      }

    $scope.connections = OpenDataService.getLocalConnections();
    $scope.nextConnection = OpenDataService.getNextConnection();
    $scope.nextConnText = OpenDataService.getNextConnectionInMinutesText();
    $scope.nextConnInMin = OpenDataService.getNextConnectionInMinutes();
    console.log("last:");
    console.log($scope.connections);
});
