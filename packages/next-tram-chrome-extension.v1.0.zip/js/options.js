nextTramOptionsApp.controller("OptionsController", function ($scope, $timeout,$filter, OpenDataService) {
	$scope.loadingLocations = false;
	$scope.connection = {};

	var settingConnections = localStorage["connection"];
	var settingConnectionsObj = {};
	if(settingConnections != null){
		$scope.connection = angular.fromJson(settingConnections);
	}

	$scope.saveConnection = function (argument) {
		localStorage["connection"] = angular.toJson($scope.connection);
		alert("saved");
		console.log(localStorage);
	};

	$scope.getStation = function(query){
		console.log("search for station with text '" + query + "'");
		$scope.loadingLocations = false;
		return OpenDataService.queryLocations(query,"station").then(function(response){
			return response.data.stations.map(function(item){
				//console.log(item);
		        return item.name;
	      	});
		});
		
	};
});